#!/usr/bin/env python

import lxml
from lxml import etree
from flask import request
from flask import Flask, jsonify
from flask import abort
from flask import send_from_directory

tasks = []
app = Flask(__name__, static_url_path='')
etree.set_default_parser(etree.XMLParser(no_network=False))

@app.route('/index')
def root():
    return send_from_directory('','index.html')

@app.route('/api/v1.0/try', methods=['POST'])
def create_task():
    if request.json:
        task = {
            'search': request.json.get('search', ""),
            'value': request.json.get('value', ""),
            'done': False
        }
        tasks.append(task)
        return jsonify({'task': task}), 201
    else:
        doc = etree.fromstring(request.data)
        return etree.tostring(doc) 

if __name__ == '__main__':
    app.run(host="0.0.0.0",debug=False)
