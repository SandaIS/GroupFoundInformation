<?php

$allowExt =  $_GET["ext"]; //'jpg,gif,jpeg,bmp';


$savepath = $_GET["uppath"];


if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/pjpeg")|| ($_FILES["file"]["type"] == "image/jpge"))
&& ($_FILES["file"]["size"] < 1000000) )
  {
   if ($_FILES["file"]["error"] > 0 )
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
    }
  else
    {
    echo "Upload: " . $_FILES["file"]["name"] . "<br />";
    echo "Type: " . $_FILES["file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";


    $fext = get_extension( $_FILES["file"]["name"]);

    if (!isAllow($fext,$allowExt)){
                die("upload Failed!");
    }

    checkDir($savepath );

    if (file_exists( $savepath . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
      $save = $savepath."/". $_FILES["file"]["name"];
      move_uploaded_file($_FILES["file"]["tmp_name"],$save);
      echo "Stored in Dir: " . $savepath."<br/>";
      echo 'upload sucessful!<br/>';
      echo $save."<br/>";
      }
    }
  }
else
  {
  echo "Invalid file";
  }
  
  
  function isAllow($exts,$allows){


  return strcmp(strpos($allows,$exts ),"");


}


function checkDir($path){

  if ( ! is_dir($path)){
         mkdir($path);
  }

}

function get_extension($file)
{
  return substr(strrchr($file, '.'), 1);
}


?>

  
  